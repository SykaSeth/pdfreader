from django.shortcuts import render

# Create your views here.
from django.shortcuts import redirect, render
from django.urls import reverse
from django.conf import settings
from django.contrib.auth.hashers import make_password, check_password
from .forms import AddInvoiceForm, AddDishForm#, AddUser
from .models import Invoices, Suppliers, Products, Dishes, DishesProducts, QRCode#, User
from .functions import verifyInvoiceFile, checkFileInfo, verifyDishPhoto, generateQRCode, getSessionMessage
import datetime


# Create your views here.

def home(request):
    return render(request, 'pdfreaderApp/index.html', {})

#################
#### INVOICE ####
#################

def invoices(request):
    invoices = Invoices.objects.all()
    return render(request, 'pdfreaderApp/invoice/all.html', {'invoices': invoices})

def invoice(request, id):
    invoice =   Invoices.objects.get(id=id)
    products=   Products.objects.filter(invoice_id=id)
    return render(request, 'pdfreaderApp/invoice/unique.html', {'invoice': invoice, 'products': products})

def add_invoice(request):
    message = {'success': [], 'error': []}
    invoices = Invoices.objects.all()
    if request.method == 'POST':
        form = AddInvoiceForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']
            file_errors = verifyInvoiceFile(file)
            if not file_errors:
                new_invoice = Invoices.objects.create(file=file, name=file.name)
                result = checkFileInfo(file)
                if result:
                    supplier = Suppliers.objects.filter(name=result['name'])
                    if not supplier:
                        supplier = Suppliers.objects.create(name=result['name'])
                        supplier.save()
                    else:
                        supplier = supplier[0]
                    date    =   result['date'].split('-')
                    if len(date[2]) == 2:
                        date[2] = '20'+date[2]
                    shipping_date = date[2]+'-'+date[1]+'-'+date[0]

                    new_invoice.supplier_id     =   supplier.id
                    new_invoice.shipping_date   =   shipping_date
                    new_invoice.save()

                    for product in result['products']:
                        new_product = Products.objects.create(invoice_id = new_invoice.id, name=product)
                        new_product.save()

                    message['success'].append('La facture a bien été ajoutée et traitée.')
                else:
                    message['error'].append('Le facture a été ajoutée mais pas reconnue et n\'a donc pas pu être traitée.')

                return render(request, 'pdfreaderApp/invoice/add.html', {'invoices': invoices, 'message': message})
                
            message['error'] = file_errors
            return render(request, 'pdfreaderApp/invoice/add.html', {'invoices': invoices, 'message': message})

        print(form.errors)
        message['error'].append('Le formulaire n\'est pas valide.')
        return render(request, 'pdfreaderApp/invoice/add.html', {'invoices': invoices, 'message': message})
    else:
        form = AddInvoiceForm()
        return render(request, 'pdfreaderApp/invoice/add.html', {'form': form})

def delete_invoice(request, id):
    message = {}
    if request.method == "POST":
        invoice = Invoices.objects.get(id=id)
        invoice.delete()
        message['success'] = ['Le fichier "'+invoice.name+'" a bien été supprimé.']
    invoices = Invoices.objects.all()
    return render(request, 'pdfreaderApp/invoice/all.html', {'invoices': invoices})

##################
###### DISH ######
##################

def dishes(request):
    response = getAllDishes()
    return render(request, 'pdfreaderApp/dish/all.html', {'response': response})

def dish(request, id):
    # user = request.session.get('user', None)
    # if user:
    #     user = User.objects.get(id=user['id'])
    # previous_page = request.META.get('HTTP_REFERER', '')

    dish    =   Dishes.objects.get(id=id)
    dps     =   DishesProducts.objects.filter(dish_id=dish.id)
    products=   []
    for dp in dps:
        product = Products.objects.get(id=dp.product_id)
        invoice = Invoices.objects.get(id=product.invoice_id)
        products.append({'id': product.id, 'name': product.name, 'invoice': {'name': invoice.name, 'path': invoice.file, 'date': invoice.shipping_date}})
    qr_code =   QRCode.objects.get(dish_id=dish.id)
    # return render(request, 'pdfreaderApp/dish/unique.html', {'dish': dish, 'products': products, 'qr_code':qr_code, 'previous_page': previous_page, 'user': user})
    return render(request, 'pdfreaderApp/dish/unique.html', {'dish': dish, 'products': products, 'qr_code':qr_code})


def add_dish(request):
    message = {'success': [], 'error': []}
    products = Products.objects.all().order_by('-id')
    response = []
    for product in products:
        invoice = Invoices.objects.get(id = product.invoice_id)
        response.append({'product': {'id': product.id, 'name': product.name}, 'invoice': {'id': invoice.id, 'name': invoice.name, 'path': invoice.file, 'date': invoice.shipping_date}})
    
    if request.method == 'POST':
        form = AddDishForm(request.POST, request.FILES)
        if form.is_valid():
            name            =   form['name'].value()
            description     =   form['description'].value()
            photo           =   request.FILES['photo']
            form_products   =   request.POST.getlist('products[]')
            image_errors    =   verifyDishPhoto(photo)

            values = {'name': name, 'description': description, 'photo': photo, 'form_products': form_products}

            if not image_errors:
                if not form_products:
                    message['error'].append('Vous devez ajouter au moins un produit au plat.')
                else:
                    new_dish    =   Dishes.objects.create(name=name, photo=photo, description=description)
                    new_dish.save()

                    qr_code_link    =   request.build_absolute_uri(reverse('dish', args=(new_dish.id,)))
                    qr_code_name    =   name.replace(' ', '_')
                    generateQRCode(qr_code_link, qr_code_name)
                    qr_code_path    =   'qr_codes/'+qr_code_name+'.png'

                    new_qr_code     =   QRCode.objects.create(dish_id=new_dish.id, path=qr_code_path, link=qr_code_link)
                    new_qr_code.save()

                    for id in form_products:
                        new_dish_product  =   DishesProducts.objects.create(dish_id=new_dish.id ,product_id=id)
                        new_dish_product.save()
                    message['success'].append('Le plat a été ajouté avec succès.')
            else:
                message['error'] = image_errors

            if message['error']:
                return render(request, 'pdfreaderApp/dish/add.html', {'values': values, 'response': response, 'message': message})
            else:
                return render(request, 'pdfreaderApp/dish/add.html', {'response': response, 'message': message})

        print(form.errors)
        message['error'].append('Le formulaire n\'est pas valide.')
        return render(request, 'pdfreaderApp/dish/add.html', {'response': response, 'message': message})
    else:
        return render(request, 'pdfreaderApp/dish/add.html', {'response': response})

def update_dish(request, id):
    message = {'success': [], 'error': []}
    products = Products.objects.all().order_by('-id')
    response = []
    for product in products:
        invoice = Invoices.objects.get(id = product.invoice_id)
        response.append({'product': {'id': product.id, 'name': product.name}, 'invoice': {'id': invoice.id, 'name': invoice.name, 'path': invoice.file, 'date': invoice.shipping_date}})

    dish    =   Dishes.objects.get(id=id)
    dps     =   DishesProducts.objects.filter(dish_id=dish.id)
    dish_products   =   [d.product_id for d in dps]

    name        =   dish.name
    description =   dish.description

    if request.method == "POST":
        form = AddDishForm(request.POST, request.FILES)
        name        =   form['name'].value()
        description =   form['description'].value()
        dish_products   =   request.POST.getlist('products[]')

        if form.is_valid():
            photo       =   request.FILES.get('photo', False)

            if not photo:
                photo = dish.photo
            else:
                image_errors = verifyDishPhoto(photo)
                message['error'] = image_errors
            
            if not dish_products:
                message['error'].append('Vous devez ajouter au moins un produit au plat.')
            
            if not message['error']:
                dish.name       =   form['name'].value()
                dish.description=   form['description'].value()
                dish.photo      =   photo
                dish.save()

                old_dish_products = DishesProducts.objects.filter(dish_id = dish.id)
                old_dish_products.delete()
                for p_id in dish_products:
                    new_dish_product  =   DishesProducts.objects.create(dish_id=dish.id,product_id=p_id)
                    new_dish_product.save()
                message['success'].append('Le plat a été modifié avec succès.')

    values = {'name': name, 'description': description, 'dish_products': dish_products}
    
    return render(request, 'pdfreaderApp/dish/update.html', {'response': response, 'values': values, 'dish': dish, 'dish_products': dish_products, 'message': message})


def delete_dish(request, id):
    message = {}
    if request.method == "POST":
        dish = Dishes.objects.get(id=id)
        dish.delete()
        response = getAllDishes()
        message['success'] = ['Le plat "'+dish.name+'" a bien été supprimé.']
        return render(request, 'pdfreaderApp/dish/all.html', {'response': response, 'message': message})
    else:
        response = getAllDishes()
        return render(request, 'pdfreaderApp/dish/all.html', {'response': response})

#################
#### QR CODE ####
#################

def qr_codes(request):    
    qr_codes = QRCode.objects.order_by('-date').all()
    response = []
    for qr_code in qr_codes:
        dish = Dishes.objects.get(id=qr_code.dish_id)
        response.append({'qr_code': qr_code, 'dish': dish})
    return render(request, 'pdfreaderApp/qrcode/all.html', {'response': response})

def qr_code(request, id):
    qr_code     =   QRCode.objects.get(id=id)
    dish        =   Dishes.objects.get(id=qr_code.dish_id)
    response    =   {'qr_code': qr_code, 'dish': dish}
    return render(request, 'pdfreaderApp/qrcode/unique.html', {'response': response})
# shortcuts functions

# ##################
# ###### USER ######
# ##################

# def register(request):
#     message = {}
#     if request.method == 'POST':
#         form = AddUser(request.POST)
#         if form.is_valid:
#             user = {
#                 'username'  :   form['username'].value(),
#                 'first_name':   form['first_name'].value(),
#                 'last_name' :   form['last_name'].value(),
#                 'email'     :   form['email'].value(),
#                 'password'  :   make_password(form['password'].value(), None, 'pbkdf2_sha256')
#             }
#             if User.objects.filter(username=user['username']):
#                 message['error'] = ['Ce nom d\'utilisateur existe déjà.']
#                 return render(request, 'pdfreaderApp/user/register.html', {'message': message})
#             new_user  =   User.objects.create(**user)
#             user['id'] = new_user.id

#             message['success'] = ['Votre compte a bien été créé.']
#             request.session['message'] = {'message': message}
#             return redirect('login')
#     else:
#         return render(request, 'pdfreaderApp/user/register.html', {})

# def login(request):
#     message = {'success': [], 'error': []}
#     if request.method == 'POST':
#         form = request.POST
#         username = form['username']
#         password = form['password']

#         if '@' in username:
#             kwargs = {'email': username}
#         else:
#             kwargs = {'username': username}
        
#         try:
#             user = User.objects.get(**kwargs)
#             if check_password(password, user.password):
#                 user.last_login = datetime.datetime.now()
#                 user.save()
#                 request.session['user'] = { 'id': user.id }
#                 request.session['message'] = {'success': ['Connecté avec succès.']}
#                 return redirect('user')
#             else:
#                 message['error'].append('Mot de passe incorrect.')
#         except:
#             message['error'].append('Identifiant non reconnu. L\'identifiant correspond à votre pseudo ou à votre adresse mail.')
#     else:
#         if 'user' in request.session:
#             return redirect('user')
        
#         message = getSessionMessage(request)

#     return render(request, 'pdfreaderApp/user/login.html', {'message': message})

# def logout(request):
#     request.session.flush()
#     return redirect('login')

# def user(request):
#     message = {}
#     if 'user' not in request.session:
#         return redirect('login')
#     else:
#         user = User.objects.get(id=request.session['user']['id'])
#         message = getSessionMessage(request)
#         return render(request, 'pdfreaderApp/user/simple.html', {'user': user, 'message': message})

# def user_details(request):
#     if 'user' not in request.session:
#         return redirect('login')
#     user = User.objects.get(id=request.session['user']['id'])
#     return render(request, 'pdfreaderApp/user/details.html', {'user': user})

# def update_user(request):
#     message = {}
#     if 'user' not in request.session:
#         return redirect('login')
#     user = User.objects.get(id=request.session['user']['id'])
#     if request.method == 'POST':
#         form = AddUser(request.POST)
#         if form.is_valid:
#             user.username = form['username'].value()
#             user.first_name = form['first_name'].value()
#             user.last_name = form['username'].value()
#             user.save()
#             message['success'] = ['Modification enregistrée.']
#     else:
#         user = User.objects.get(id=request.session['user']['id'])
#     return render(request, 'pdfreaderApp/user/update.html', {'user': user, 'message': message})

# def delete_user(request):
#     return render(request, 'pdfreaderApp/user/login.html', {})

# ###################
# ###### ADMIN ######
# ###################

# def admin(request):
#     if 'user' not in request.session:
#         return redirect('login')
#     else:
#         user = User.objects.get(id=request.session['user']['id'])
#         if user.role != 'ADMIN':
#             return redirect('user')
#         return render(request, 'pdfreaderApp/user/admin/simple.html', {'user': user})

# def admin_users(request):
#     if 'user' not in request.session:
#         return redirect('login')
#     else:
#         user = User.objects.get(id=request.session['user']['id'])
#         if user.role != 'ADMIN':
#             return redirect('user')
    
#     users = User.objects.order_by('-date_joined').all()
#     return render(request, 'pdfreaderApp/user/admin/users.html', {'users': users})

###################################
####### SHORTCUTS FUNCTIONS #######
###################################

def getAllDishes():
    dishes = Dishes.objects.order_by('-date').all()
    result = []
    for dish in dishes:
        dps = DishesProducts.objects.filter(dish_id=dish.id)
        products = []
        for dp in dps:
            product = Products.objects.get(id=dp.product_id)
            products.append({'id': product.id, 'name': product.name})
        result.append({'dish': {'id': dish.id, 'name': dish.name, 'photo': dish.photo, 'date': dish.date}, 'products': products})
    return result
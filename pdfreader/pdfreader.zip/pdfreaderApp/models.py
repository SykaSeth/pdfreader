from email.policy import default
from django.conf import settings
from django.db import models
from django.contrib.auth.models import AbstractUser
import datetime

import os

# Create your models here.

class Suppliers(models.Model):
    name        =   models.CharField(max_length=255)
    website     =   models.CharField(max_length=255, blank=True)
    description =   models.CharField(max_length=255, blank=True)
    date        =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

    class Meta:
        db_table = "suppliers"

    def __str__(self):
        return self.name

class Invoices(models.Model):
    supplier    =   models.ForeignKey(Suppliers, on_delete=models.CASCADE, blank=True, null=True)
    shipping_date = models.DateField(blank=True, default=datetime.date.today)
    name        =   models.CharField(max_length = 255)
    file        =   models.FileField(db_column='path', upload_to = 'invoices')
    date        =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)
    
    class Meta:
        db_table = "invoices"

    def __str__(self):
        return self.name

    def delete(self, *args, **kwargs):
        self.file.delete()
        super().delete(*args, **kwargs)

class Products(models.Model):
    invoice =   models.ForeignKey(Invoices, on_delete=models.CASCADE)
    name    =   models.CharField(max_length=255)
    date    =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

    class Meta:
        db_table = "products"

    def __str__(self):
        return self.name

class Dishes(models.Model):
    name        =   models.CharField(max_length=255)
    description =   models.TextField(max_length=1000, blank=True, default='')
    photo       =   models.ImageField(upload_to='dishes', blank=True, default='dishes/food.jpg', max_length=100)
    date        =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

    class Meta:
        db_table = "dishes"
        ordering = ('-date',)

    def __str__(self):
        return self.name

    def delete(self, *args, **kwargs):
        if self.photo != 'dishes/food.jpg':
            self.photo.delete()
        super().delete(*args, **kwargs)

class DishesProducts(models.Model):
    dish    =   models.ForeignKey(Dishes, on_delete=models.CASCADE)
    product =   models.ForeignKey(Products, on_delete=models.CASCADE)
    date    =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

    class Meta:
        db_table = "dishes_products"

class QRCode(models.Model):
    dish    =   models.ForeignKey(Dishes, on_delete=models.CASCADE)
    link    =   models.CharField(max_length=255)
    path    =   models.ImageField(max_length=255)
    date    =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

    class Meta:
        db_table = "qr_code"
        ordering = ('-date',)

    def delete(self, *args, **kwargs):
        os.remove(settings.MEDIA_ROOT+'/'+self.path)
        super().delete(*args, **kwargs)
        

# class User(AbstractUser):
#     class Role(models.TextChoices):
#         ADMIN   =   "ADMIN", 'Administrateur'
#         USER    =   "USER", 'Utilisateur'

#     base_role   =   Role.USER

#     role        =   models.CharField(max_length=255, default=base_role)

#     def save(self, *args, **kwargs):
#         return super().save(*args, **kwargs)

#     def __str__(self):
#         return self.username

            
# class Role(models.Model):
#     number      =   models.IntegerField()
#     name        =   models.CharField(max_length=255)
#     date        =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

#     class Meta:
#         db_table = "role"

#     def __str__(self):
#         return self.name

# class User(models.Model):
#     first_name  =   models.CharField(max_length=255)
#     last_name   =   models.CharField(max_length=255)
#     age         =   models.IntegerField()
#     email       =   models.EmailField(max_length=255)
#     password    =   models.CharField(max_length=255)
#     role        =   models.ForeignKey(Role, blank=True, default=2, on_delete=models.SET_DEFAULT)
#     modif_date  =   models.DateTimeField(blank=True, null=True)
#     date        =   models.DateTimeField(auto_now_add=True, blank=True, editable=False)

#     class Meta:
#         db_table = "user"
#         ordering = ('-date',)

#     def __str__(self):
#         return self.first_name+' '+self.last_name
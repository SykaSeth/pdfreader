from django import forms
from .models import Invoices, Dishes#, User

class AddInvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoices
        fields = ['file']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'

class AddDishForm(forms.ModelForm):
    class Meta:
        model = Dishes
        fields = ['name', 'photo', 'description']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'